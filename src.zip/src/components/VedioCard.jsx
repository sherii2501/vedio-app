import React,{useState} from 'react'
import {Card,Modal} from 'react-bootstrap';


function VideoCard() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
    <Card>
      <Card.Img variant="top" onClick={handleShow} src="https://miro.medium.com/v2/resize:fit:1200/1*y6C4nSvy2Woe0m7bWEn4BA.png" />
      <Card.Body>
        <Card.Title className='d-flex justify-content-between align-items-center'>
          <h6>Video Caption</h6>
          <button className='btn'><i class="fa-solid fa-trash text-danger"></i></button>
        </Card.Title>
      </Card.Body>
    </Card>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <iframe width={"100%"} height="397" src="https://www.youtube.com/embed/--82JQ3NubI?autoplay=1" title="Heeriye (Official Video) Jasleen Royal ft. Arijit Singh | Dulquer Salmaan | Aditya| Taani | Memories" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>        </Modal.Body>
      </Modal>
    </>
  )
}

export default VideoCard