import React from 'react'
import { Link } from 'react-router-dom'

function WatchHistory() {
  return (
    <>
      <div className="container mt-5 mb-5 d-flex justify-content-between">
        <h3>Watch History</h3>
        <Link to='/home' className='d-flex align-items-center' style={{ textDecoration: 'none', color: 'white', fontSize: '20px' }}><i className="fa-solid fa-arrow-left me-2"></i>Back to Home</Link>
      </div>
      <table className='table mt-5 mb-5 container'>
        <thead>
          <tr>
            <th>#</th>
            <th>Caption</th>
            <th>URL</th>
            <th>Time stamp</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>1</th>
            <th>aaa</th>
            <th><a href="https://fontawesome.com/">https://fontawesome.com/</a></th>
            <th>4/10/23</th>
          </tr>
        </tbody>
      </table>
    </>
  )
}

export default WatchHistory